A21-F1 corrective evidence: newly produced corrective runs, not original runs.

Entry: b1feaf7bde9083eccaef10b6333c4bfe864c7cf0
Entry tree: 7f3f40a71512e53be6d570902eb074cd364fc9c2
Production implementation: 9bc10bb0313505697ce7a4e46e4612edec7e9814
Unchanged decoder blob: 5a60b7a1aed1bfb93a78817224e11f89276e5868
Substantial test correction: 9091d35b80ac30116b142adf4f8966450debba6e
Final producing test correction: 2007126aec85dcd4b470e18d08bbed01ff67a942
Final test blob: b064d22dd678593e4f7d3133d9c3679de51e5a80, mode 100644

authoritative/ is the final focused suite at 2007126...:
cargo test --locked --target x86_64-unknown-linux-gnu -p qbind-wire --test block_proposal_preflight_tests -- --test-threads=1
QBIND_A21_EVIDENCE_ROOT pointed at authoritative/ in the retained directory.
5 passed; 0 failed; 2 intentionally ignored context-dependent entries.
26 candidate children; 6 calibration children; 2 setup refusals; 5 cleanup
children (one normal, four terminated); 2 synthetic valid outcomes; 89
synthetic invalid outcomes; 4 actual dispatch-negative outcomes.

baseline/ is the actual exact baseline decoder plus the final test overlay:
cargo test --locked --target x86_64-unknown-linux-gnu -p qbind-wire --test block_proposal_preflight_tests -- --ignored --exact baseline_small_controls --test-threads=1
Baseline source commit: 73c2ad6e249ff77f6fd10761d1a2f90c34d9a903
Baseline tree: cee733f72d38de1f67fa6965b61cd10cb0744ce6
Baseline decoder blob: 9233aaaa21196a3e6e9a3af8303e076671f73718
Only final test blob b064d22... was overlaid in the isolated worktree.
1 passed; counts 2 and 8 only. No huge baseline counts.
The baseline-overlay-identity.txt file records the exact environment and command.

authoritative-9091d35/ and baseline-9091d35/ contain the earlier committed
corrective run. development/ contains non-authoritative development results,
including an initial compilation error corrected before producing commits.
These are not original-run files and do not recast original passing results.

toolchain-profile-ffi.txt records actual compiler, target, profile and FFI
prerequisites. ffi-abi-check.c was copied from the original evidence and
executed anew; it is not misrepresented as a newly recovered original result.
provenance/ contains the final test bytes and raw revision headers.
decoded-record-summary.json is newly generated from final raw files for
inspection; records.bin/events.bin are the authoritative raw evidence.
Parent logs retain actual statuses, timeouts, termination, reap and injection
labels. Synthetic guard reasons are not observed allocator failures.

Original evidence remains in the separate a21-f1-evidence directory, with
its original AUTHORITATIVE-MANIFEST.txt (102 files, 14480 bytes, SHA-256
942f0041fd609d044b66db0be7581e4f096517b70abed2aa3069e00997658e3a).
The separately packaged original archive includes those exact files unchanged.

MANIFEST.txt lists relative file paths, sizes and SHA-256 values for this
corrective evidence directory, excluding itself. It is not a signature.
The temporary baseline worktree and build directory were removed and are
not retained evidence paths.

External evidence transfer is BLOCKED: this session has no general attachment
or task-artifact upload facility. Local archives are prepared for transfer,
not downloadable task artifacts. No GitHub issue, release, workflow or other
publication was created to work around that limitation.

Independent post-correction review PENDING. A21-F1 OPEN.
Implementation IMPLEMENTED - VERIFICATION PENDING. OBL-PAR-1/E12/E13 open.
Activation DISABLED. Public DevNet NO-GO. No node execution or activation.
