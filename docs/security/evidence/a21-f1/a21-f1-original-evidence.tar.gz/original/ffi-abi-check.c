#define _GNU_SOURCE 1
#include <errno.h>
#include <stddef.h>
#include <sys/prctl.h>
#include <sys/types.h>
#include <unistd.h>
#include <x86_64-linux-gnu/bits/errno.h>
_Static_assert(PR_SET_DUMPABLE == 4, "PR_SET_DUMPABLE");
_Static_assert(PR_GET_DUMPABLE == 3, "PR_GET_DUMPABLE");
_Static_assert(EINTR == 4, "EINTR");
_Static_assert(sizeof(off_t) == 8, "off_t width");
_Static_assert(sizeof(ssize_t) == 8, "ssize_t width");
_Static_assert(sizeof(size_t) == 8, "size_t width");
_Static_assert(sizeof(unsigned long) == 8, "c_ulong width");
static int (*prctl_declaration)(int, ...) = prctl;
static ssize_t (*pwrite_declaration)(int, const void *, size_t, off_t) = pwrite;
static int *(*errno_declaration)(void) = __errno_location;
int main(void) { return prctl_declaration == 0 || pwrite_declaration == 0 || errno_declaration == 0; }
